# BlockDrop 🧩

A vibrant 8×8 block-drop puzzle for iOS. SwiftUI only, iOS 16+, **zero ads, zero
analytics, zero network calls.** Single-file game state in one `ObservableObject`.

## How to play
Drag the 3 pieces from the tray onto the board. A ghost shows where a piece
will land (red = won't fit, snaps back). Fill full rows/columns to clear them.
Clear several lines at once for combo bonuses, and clear on back-to-back
placements to build a streak multiplier (up to 5×). Place all 3 pieces and a new
set spawns. If none of the remaining pieces fit anywhere, it's game over.

## Scoring
- 10 pts per cleared block
- Combo bonus: 2 lines +50, 3 lines +100, 4 lines +200, 5+ lines +400
- Streak multiplier: 1× / 1.5× / 2× / 3× / 5× (cap)
- Best score persists via `UserDefaults`

## Project layout
```
BlockDrop/
├── BlockDrop.xcodeproj/         # open this in Xcode
└── BlockDrop/
    ├── BlockDropApp.swift       # @main entry
    ├── ContentView.swift        # root + drag/ghost controller
    ├── GameViewModel.swift      # all state, pieces, scoring, clears, game over
    ├── BoardView.swift          # 8×8 grid + clear-flash + ghost preview
    ├── TrayView.swift           # 3-piece tray + drag gestures
    ├── HUDView.swift            # combo counter (streak / score / best)
    ├── GameOverView.swift       # final score + Play Again
    ├── Particles.swift          # haptics + particle burst + screen flash
    └── Assets.xcassets/         # app icon + accent color
```

## Run it
1. Open `BlockDrop.xcodeproj` in Xcode 15+ (macOS).
2. Pick an iPhone simulator (or your device) and press ▶︎. That's it — no
   packages, no signing needed for the simulator.

## Build an .ipa  (needs macOS + Xcode)
A real `.ipa` is an iOS binary and can only be produced by Apple's toolchain on a
Mac. From the `BlockDrop` folder:

```bash
# Unsigned .ipa (re-sign with AltStore / Sideloadly to put on your iPhone):
./build_ipa.sh

# Signed .ipa with your free or paid Apple developer account:
TEAM_ID=YOURTEAMID ./build_ipa.sh signed
```

Find your Team ID in Xcode → Settings → Accounts, or at developer.apple.com →
Membership. To install on a physical iPhone you must sign it (free personal teams
work — the app just expires after 7 days and needs a re-install).
