#!/bin/bash
#
# build_ipa.sh — build BlockDrop into a .ipa on macOS (requires Xcode).
# Usage:
#   ./build_ipa.sh            # unsigned .ipa (for AltStore/Sideloadly/etc. to re-sign)
#   ./build_ipa.sh signed     # signed .ipa via your Apple developer team (set TEAM_ID)
#
set -euo pipefail
SCHEME="BlockDrop"
PROJECT="BlockDrop.xcodeproj"
BUILD_DIR="build"
ARCHIVE="$BUILD_DIR/BlockDrop.xcarchive"
MODE="${1:-unsigned}"

rm -rf "$BUILD_DIR"
mkdir -p "$BUILD_DIR"

if [ "$MODE" = "signed" ]; then
  : "${TEAM_ID:?Set TEAM_ID to your Apple Developer Team ID, e.g. TEAM_ID=ABCDE12345 ./build_ipa.sh signed}"
  echo "==> Archiving (signed, team $TEAM_ID)…"
  xcodebuild -project "$PROJECT" -scheme "$SCHEME" \
    -configuration Release -destination 'generic/platform=iOS' \
    -archivePath "$ARCHIVE" archive \
    DEVELOPMENT_TEAM="$TEAM_ID"

  cat > "$BUILD_DIR/ExportOptions.plist" <<PLIST
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0"><dict>
  <key>method</key><string>development</string>
  <key>teamID</key><string>$TEAM_ID</string>
  <key>signingStyle</key><string>automatic</string>
  <key>stripSwiftSymbols</key><true/>
  <key>compileBitcode</key><false/>
</dict></plist>
PLIST

  echo "==> Exporting signed .ipa…"
  xcodebuild -exportArchive -archivePath "$ARCHIVE" \
    -exportOptionsPlist "$BUILD_DIR/ExportOptions.plist" \
    -exportPath "$BUILD_DIR/export"
  echo "✅ Signed IPA: $BUILD_DIR/export/BlockDrop.ipa"
else
  echo "==> Archiving (unsigned)…"
  xcodebuild -project "$PROJECT" -scheme "$SCHEME" \
    -configuration Release -destination 'generic/platform=iOS' \
    -archivePath "$ARCHIVE" archive \
    CODE_SIGN_IDENTITY="" CODE_SIGNING_REQUIRED=NO CODE_SIGNING_ALLOWED=NO

  echo "==> Packaging unsigned .ipa…"
  rm -rf "$BUILD_DIR/Payload"
  mkdir -p "$BUILD_DIR/Payload"
  cp -R "$ARCHIVE/Products/Applications/BlockDrop.app" "$BUILD_DIR/Payload/"
  ( cd "$BUILD_DIR" && zip -r -q BlockDrop-unsigned.ipa Payload && rm -rf Payload )
  echo "✅ Unsigned IPA: $BUILD_DIR/BlockDrop-unsigned.ipa"
  echo "   Install with AltStore / Sideloadly / your dev tool (they re-sign it for your device)."
fi
