//
//  BoardView.swift
//  BlockDrop
//

import SwiftUI

// MARK: - Shared layout constants

enum Layout {
    static let cell: CGFloat = 40            // board cell size in points
    static let cellGap: CGFloat = 2          // gap between cells
    static let cellCorner: CGFloat = 6
    static let boardCorner: CGFloat = 14
    static let boardPad: CGFloat = 6         // inner padding around the grid
    static let trayCell: CGFloat = 26        // cell size for pieces resting in the tray
    static let dragSensitivity: CGFloat = 2.0 // finger movement is amplified by this factor

    static var boardContent: CGFloat {
        CGFloat(GameConfig.gridSize) * cell
    }
}

// MARK: - Ghost preview info

struct GhostInfo: Equatable {
    let origin: GridPoint   // top-left anchor
    let shape: PieceShape
    let valid: Bool
}

// MARK: - Board

struct BoardView: View {
    @ObservedObject var vm: GameViewModel
    let ghost: GhostInfo?
    /// Reports the grid's frame in GLOBAL coordinates whenever it changes.
    let onFrame: (CGRect) -> Void

    var body: some View {
        ZStack {
            // Background panel
            RoundedRectangle(cornerRadius: Layout.boardCorner)
                .fill(Color(red: 0.10, green: 0.11, blue: 0.20))
                .overlay(
                    RoundedRectangle(cornerRadius: Layout.boardCorner)
                        .stroke(Color.white.opacity(0.06), lineWidth: 1)
                )

            // Grid (proper stack layout -> correct intrinsic size)
            VStack(spacing: 0) {
                ForEach(0..<GameConfig.gridSize, id: \.self) { r in
                    HStack(spacing: 0) {
                        ForEach(0..<GameConfig.gridSize, id: \.self) { c in
                            cellView(row: r, col: c)
                                .frame(width: Layout.cell, height: Layout.cell)
                        }
                    }
                }
            }
            .background(
                GeometryReader { geo in
                    Color.clear
                        .onAppear { onFrame(geo.frame(in: .global)) }
                        .onChange(of: geo.frame(in: .global)) { onFrame($0) }
                }
            )
        }
        .frame(width: Layout.boardContent + Layout.boardPad * 2,
               height: Layout.boardContent + Layout.boardPad * 2)
    }

    @ViewBuilder
    private func cellView(row r: Int, col c: Int) -> some View {
        let point = GridPoint(row: r, col: c)
        let filled = vm.grid[r][c]
        let isClearing = vm.clearingCells.contains(point)
        let ghostCell = ghostColor(row: r, col: c)

        RoundedRectangle(cornerRadius: Layout.cellCorner)
            .fill(fillColor(filled: filled, ghost: ghostCell, clearing: isClearing))
            .overlay(
                RoundedRectangle(cornerRadius: Layout.cellCorner)
                    .stroke(Color.white.opacity(filled == nil && ghostCell == nil ? 0.05 : 0.16),
                            lineWidth: 1)
            )
            .overlay(
                Group {
                    if filled != nil || ghostCell != nil {
                        RoundedRectangle(cornerRadius: Layout.cellCorner)
                            .fill(
                                LinearGradient(
                                    colors: [Color.white.opacity(0.28), Color.clear],
                                    startPoint: .top, endPoint: .center)
                            )
                    }
                }
            )
            .padding(Layout.cellGap / 2)
            .scaleEffect(isClearing ? 1.12 : 1.0)
            .animation(.easeInOut(duration: 0.18), value: isClearing)
    }

    private func fillColor(filled: Cell, ghost: Color?, clearing: Bool) -> Color {
        if clearing { return Color.white }
        if let f = filled { return BlockPalette.color(f) }
        if let g = ghost { return g }
        return Color.white.opacity(0.04)   // empty cell
    }

    private func ghostColor(row r: Int, col c: Int) -> Color? {
        guard let ghost else { return nil }
        for p in ghost.shape.cells {
            if ghost.origin.row + p.row == r && ghost.origin.col + p.col == c {
                let base = BlockPalette.color(ghost.shape.colorIndex)
                return ghost.valid ? base.opacity(0.55) : Color.red.opacity(0.4)
            }
        }
        return nil
    }
}
