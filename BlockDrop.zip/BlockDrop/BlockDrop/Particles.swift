//
//  Particles.swift
//  BlockDrop
//
//  Haptics helper + particle burst + screen flash overlays for big combos.
//

import SwiftUI
#if canImport(UIKit)
import UIKit
#endif

// MARK: - Haptics

enum Haptics {
    #if canImport(UIKit)
    private static let light = UIImpactFeedbackGenerator(style: .light)
    private static let medium = UIImpactFeedbackGenerator(style: .medium)
    private static let heavy = UIImpactFeedbackGenerator(style: .heavy)
    private static let notify = UINotificationFeedbackGenerator()
    #endif

    static func placement() {
        #if canImport(UIKit)
        light.impactOccurred()
        #endif
    }

    static func lineClear() {
        #if canImport(UIKit)
        medium.impactOccurred()
        #endif
    }

    static func combo() {
        #if canImport(UIKit)
        heavy.impactOccurred(intensity: 1.0)
        #endif
    }

    static func gameOver() {
        #if canImport(UIKit)
        notify.notificationOccurred(.error)
        #endif
    }
}

// MARK: - Particle model

private struct Particle: Identifiable {
    let id = UUID()
    var pos: CGPoint
    var velocity: CGVector
    var color: Color
    var size: CGFloat
    var life: Double      // 1.0 -> 0.0
}

/// Spawns a short particle burst at `center` each time `trigger` changes.
struct ParticleBurstView: View {
    let trigger: Int
    let center: CGPoint

    @State private var particles: [Particle] = []
    @State private var lastTrigger: Int = 0

    var body: some View {
        TimelineView(.animation) { context in
            Canvas { ctx, _ in
                for p in particles {
                    var circle = Path()
                    let s = p.size * p.life
                    circle.addEllipse(in: CGRect(x: p.pos.x - s/2, y: p.pos.y - s/2,
                                                 width: s, height: s))
                    ctx.fill(circle, with: .color(p.color.opacity(p.life)))
                }
            }
            .onChange(of: context.date) { _ in step() }
        }
        .allowsHitTesting(false)
        .onChange(of: trigger) { newValue in
            guard newValue != lastTrigger else { return }
            lastTrigger = newValue
            spawn(at: center)
        }
    }

    private func spawn(at c: CGPoint) {
        let colors = BlockPalette.colors
        var new: [Particle] = []
        for _ in 0..<36 {
            let angle = Double.random(in: 0..<(2 * .pi))
            let speed = Double.random(in: 2.0...7.5)
            new.append(Particle(
                pos: c,
                velocity: CGVector(dx: cos(angle) * speed, dy: sin(angle) * speed),
                color: colors.randomElement() ?? .yellow,
                size: CGFloat.random(in: 8...16),
                life: 1.0
            ))
        }
        particles.append(contentsOf: new)
    }

    private func step() {
        guard !particles.isEmpty else { return }
        for i in particles.indices {
            particles[i].pos.x += particles[i].velocity.dx
            particles[i].pos.y += particles[i].velocity.dy
            particles[i].velocity.dy += 0.25   // gravity
            particles[i].life -= 0.035
        }
        particles.removeAll { $0.life <= 0 }
    }
}

/// A full-screen white flash that pops when `trigger` changes (big combos).
struct ScreenFlashView: View {
    let trigger: Int
    @State private var opacity: Double = 0
    @State private var lastTrigger: Int = 0

    var body: some View {
        Rectangle()
            .fill(Color.white)
            .opacity(opacity)
            .ignoresSafeArea()
            .allowsHitTesting(false)
            .onChange(of: trigger) { newValue in
                guard newValue != lastTrigger else { return }
                lastTrigger = newValue
                opacity = 0.55
                withAnimation(.easeOut(duration: 0.45)) { opacity = 0 }
            }
    }
}
