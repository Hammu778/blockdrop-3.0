//
//  GameOverView.swift
//  BlockDrop
//

import SwiftUI

struct GameOverView: View {
    @ObservedObject var vm: GameViewModel
    @State private var appear = false

    var isNewBest: Bool { vm.score >= vm.bestScore && vm.score > 0 }

    var body: some View {
        ZStack {
            Color.black.opacity(0.65).ignoresSafeArea()

            VStack(spacing: 18) {
                Text("GAME OVER")
                    .font(.system(size: 34, weight: .heavy, design: .rounded))
                    .foregroundColor(.white)
                    .tracking(2)

                if isNewBest {
                    Text("🏆 NEW BEST!")
                        .font(.system(size: 18, weight: .heavy, design: .rounded))
                        .foregroundColor(Color(red: 1.0, green: 0.82, blue: 0.26))
                }

                VStack(spacing: 10) {
                    resultRow("Final Score", "\(vm.score)",
                              Color(red: 0.40, green: 0.55, blue: 0.99))
                    resultRow("Best Score", "\(vm.bestScore)",
                              Color(red: 0.36, green: 0.84, blue: 0.50))
                }
                .padding(.vertical, 8)

                Button {
                    Haptics.placement()
                    withAnimation(.easeInOut) { vm.resetGame() }
                } label: {
                    Text("PLAY AGAIN")
                        .font(.system(size: 20, weight: .heavy, design: .rounded))
                        .foregroundColor(.white)
                        .frame(maxWidth: .infinity)
                        .padding(.vertical, 16)
                        .background(
                            RoundedRectangle(cornerRadius: 16)
                                .fill(LinearGradient(
                                    colors: [Color(red: 1.0, green: 0.45, blue: 0.30),
                                             Color(red: 1.0, green: 0.70, blue: 0.20)],
                                    startPoint: .leading, endPoint: .trailing))
                        )
                }
                .padding(.top, 6)
            }
            .padding(28)
            .background(
                RoundedRectangle(cornerRadius: 24)
                    .fill(Color(red: 0.10, green: 0.11, blue: 0.20))
                    .overlay(RoundedRectangle(cornerRadius: 24)
                        .stroke(Color.white.opacity(0.12), lineWidth: 1))
            )
            .padding(.horizontal, 36)
            .scaleEffect(appear ? 1.0 : 0.8)
            .opacity(appear ? 1.0 : 0.0)
        }
        .onAppear {
            withAnimation(.spring(response: 0.4, dampingFraction: 0.7)) { appear = true }
        }
    }

    private func resultRow(_ title: String, _ value: String, _ tint: Color) -> some View {
        HStack {
            Text(title)
                .font(.system(size: 16, weight: .semibold, design: .rounded))
                .foregroundColor(.white.opacity(0.7))
            Spacer()
            Text(value)
                .font(.system(size: 24, weight: .heavy, design: .rounded))
                .foregroundColor(tint)
        }
        .frame(width: 220)
    }
}
