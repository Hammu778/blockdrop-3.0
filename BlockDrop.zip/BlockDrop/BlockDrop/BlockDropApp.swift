//
//  BlockDropApp.swift
//  BlockDrop
//
//  A vibrant 8x8 block puzzle. No ads, no analytics, no network.
//

import SwiftUI

@main
struct BlockDropApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
                .preferredColorScheme(.dark)
        }
    }
}
