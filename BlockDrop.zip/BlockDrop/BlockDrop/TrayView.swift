//
//  TrayView.swift
//  BlockDrop
//

import SwiftUI

/// Renders a single piece shape at a given cell size (used in the tray and
/// for the floating drag preview).
struct PieceShapeView: View {
    let shape: PieceShape
    let cellSize: CGFloat
    var opacity: Double = 1.0

    var body: some View {
        ZStack(alignment: .topLeading) {
            ForEach(Array(shape.cells.enumerated()), id: \.offset) { _, p in
                RoundedRectangle(cornerRadius: cellSize * 0.18)
                    .fill(BlockPalette.color(shape.colorIndex))
                    .overlay(
                        RoundedRectangle(cornerRadius: cellSize * 0.18)
                            .fill(LinearGradient(colors: [Color.white.opacity(0.30), Color.clear],
                                                 startPoint: .top, endPoint: .center))
                    )
                    .overlay(
                        RoundedRectangle(cornerRadius: cellSize * 0.18)
                            .stroke(Color.black.opacity(0.18), lineWidth: 1)
                    )
                    .frame(width: cellSize - 2, height: cellSize - 2)
                    .offset(x: CGFloat(p.col) * cellSize, y: CGFloat(p.row) * cellSize)
            }
        }
        .frame(width: CGFloat(shape.width) * cellSize,
               height: CGFloat(shape.height) * cellSize,
               alignment: .topLeading)
        .opacity(opacity)
    }
}

/// The tray of 3 pieces below the board. Reports drag events upward.
struct TrayView: View {
    @ObservedObject var vm: GameViewModel

    let draggingID: UUID?
    let onDragChanged: (UUID, PieceShape, CGPoint) -> Void
    let onDragEnded: (UUID, PieceShape) -> Void

    var body: some View {
        HStack(spacing: 0) {
            ForEach(vm.tray) { piece in
                slot(for: piece)
                    .frame(maxWidth: .infinity)
            }
        }
        .frame(height: Layout.trayCell * 5 + 16)
        .padding(.horizontal, 8)
    }

    @ViewBuilder
    private func slot(for piece: TrayPiece) -> some View {
        let isDragging = draggingID == piece.id
        ZStack {
            if piece.placed {
                // Empty slot placeholder
                RoundedRectangle(cornerRadius: 10)
                    .fill(Color.white.opacity(0.03))
                    .frame(width: Layout.trayCell * 3, height: Layout.trayCell * 3)
            } else {
                PieceShapeView(shape: piece.shape, cellSize: Layout.trayCell)
                    .opacity(isDragging ? 0.25 : 1.0)
                    .contentShape(Rectangle())
                    .gesture(
                        DragGesture(coordinateSpace: .named(Layout.coordSpace))
                            .onChanged { value in
                                onDragChanged(piece.id, piece.shape, value.location)
                            }
                            .onEnded { _ in
                                onDragEnded(piece.id, piece.shape)
                            }
                    )
            }
        }
        .frame(height: Layout.trayCell * 3)
    }
}
