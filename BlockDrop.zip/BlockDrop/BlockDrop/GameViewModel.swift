//
//  GameViewModel.swift
//  BlockDrop
//
//  All game state, models, and logic live here.
//

import SwiftUI
import Combine

// MARK: - Constants

enum GameConfig {
    static let gridSize = 8          // 8x8 board
    static let trayCount = 3         // pieces shown at a time
    static let pointsPerBlock = 10
    static let bestScoreKey = "BlockDrop.bestScore"
}

// MARK: - Piece definition

/// A piece shape, defined as a set of (row, col) offsets relative to its
/// own top-left bounding box. Pieces cannot be rotated.
struct PieceShape: Identifiable, Equatable {
    let id: String
    let cells: [GridPoint]
    let colorIndex: Int

    /// Number of columns the shape spans.
    var width: Int { (cells.map { $0.col }.max() ?? 0) + 1 }
    /// Number of rows the shape spans.
    var height: Int { (cells.map { $0.row }.max() ?? 0) + 1 }
    var blockCount: Int { cells.count }
}

/// A simple integer grid coordinate.
struct GridPoint: Equatable, Hashable {
    let row: Int
    let col: Int
}

/// A live piece sitting in the tray (shape + whether it's been used).
struct TrayPiece: Identifiable, Equatable {
    let id = UUID()
    let shape: PieceShape
    var placed: Bool = false
}

// MARK: - Piece catalog

enum PieceCatalog {

    /// The full pool of shapes pieces are randomized from.
    static let all: [PieceShape] = {
        var list: [PieceShape] = []
        var c = 0
        func add(_ id: String, _ cells: [(Int, Int)]) {
            list.append(PieceShape(id: id,
                                   cells: cells.map { GridPoint(row: $0.0, col: $0.1) },
                                   colorIndex: c % BlockPalette.colors.count))
            c += 1
        }

        // Single
        add("1x1", [(0,0)])

        // Horizontal bars
        add("1x2", [(0,0),(0,1)])
        add("1x3", [(0,0),(0,1),(0,2)])
        add("1x4", [(0,0),(0,1),(0,2),(0,3)])
        add("1x5", [(0,0),(0,1),(0,2),(0,3),(0,4)])

        // Vertical bars
        add("2x1", [(0,0),(1,0)])
        add("3x1", [(0,0),(1,0),(2,0)])
        add("4x1", [(0,0),(1,0),(2,0),(3,0)])
        add("5x1", [(0,0),(1,0),(2,0),(3,0),(4,0)])

        // Squares
        add("2x2", [(0,0),(0,1),(1,0),(1,1)])
        add("3x3", [(0,0),(0,1),(0,2),(1,0),(1,1),(1,2),(2,0),(2,1),(2,2)])

        // Small L (2x2 corner, 3 cells) — four orientations baked in (no runtime rotation)
        add("smallL_a", [(0,0),(1,0),(1,1)])
        add("smallL_b", [(0,0),(0,1),(1,0)])
        add("smallL_c", [(0,0),(0,1),(1,1)])
        add("smallL_d", [(0,1),(1,0),(1,1)])

        // L-shape (3 tall + foot)
        add("L", [(0,0),(1,0),(2,0),(2,1)])
        // J-shape
        add("J", [(0,1),(1,1),(2,1),(2,0)])
        // T-shape
        add("T", [(0,0),(0,1),(0,2),(1,1)])
        // S-shape
        add("S", [(1,0),(1,1),(0,1),(0,2)])
        // Z-shape
        add("Z", [(0,0),(0,1),(1,1),(1,2)])

        return list
    }()

    static func randomShape() -> PieceShape {
        all.randomElement()!
    }
}

// MARK: - Colors

enum BlockPalette {
    /// Vibrant colors; each piece picks one by index.
    static let colors: [Color] = [
        Color(red: 0.99, green: 0.36, blue: 0.36), // red
        Color(red: 1.00, green: 0.60, blue: 0.20), // orange
        Color(red: 1.00, green: 0.82, blue: 0.26), // yellow
        Color(red: 0.36, green: 0.84, blue: 0.50), // green
        Color(red: 0.26, green: 0.78, blue: 0.92), // cyan
        Color(red: 0.40, green: 0.55, blue: 0.99), // blue
        Color(red: 0.70, green: 0.46, blue: 0.99), // purple
        Color(red: 0.98, green: 0.45, blue: 0.78), // pink
    ]

    static func color(_ index: Int) -> Color {
        colors[((index % colors.count) + colors.count) % colors.count]
    }
}

// MARK: - Cell state

/// A board cell: empty (nil) or filled with a color index.
typealias Cell = Int?

// MARK: - View Model

@MainActor
final class GameViewModel: ObservableObject {

    // Board: grid[row][col] -> color index or nil
    @Published var grid: [[Cell]]
    @Published var tray: [TrayPiece] = []
    @Published var score: Int = 0
    @Published var bestScore: Int = 0
    @Published var streak: Int = 0
    @Published var isGameOver: Bool = false

    // Transient UI signals
    @Published var clearingCells: Set<GridPoint> = []   // cells flashing before removal
    @Published var comboPulse: Int = 0                   // increments to trigger HUD animation
    @Published var lastLinesCleared: Int = 0             // lines cleared on the most recent placement
    @Published var lastGain: Int = 0                     // points gained on the most recent placement
    @Published var screenFlash: Int = 0                  // increments for big-combo flash
    @Published var burstTrigger: Int = 0                 // increments to spawn a particle burst
    @Published var burstCenter: CGPoint = .zero          // where to spawn the burst (global coords)

    private let size = GameConfig.gridSize
    /// Consecutive placements that cleared no lines. Streak breaks at 3.
    private var missCount: Int = 0
    private let streakGrace: Int = 3

    /// Score multiplier currently in effect for the active streak.
    var currentMultiplier: Double { streakMultiplier(streak) }

    init() {
        grid = Array(repeating: Array(repeating: nil, count: GameConfig.gridSize),
                     count: GameConfig.gridSize)
        bestScore = UserDefaults.standard.integer(forKey: GameConfig.bestScoreKey)
        refillTray()
    }

    // MARK: Tray management

    func refillTray() {
        tray = (0..<GameConfig.trayCount).map { _ in TrayPiece(shape: PieceCatalog.randomShape()) }
    }

    private var activePieces: [TrayPiece] { tray.filter { !$0.placed } }

    // MARK: Placement validity

    /// Can `shape` be placed with its top-left anchored at (row, col)?
    func canPlace(_ shape: PieceShape, atRow row: Int, col: Int) -> Bool {
        for p in shape.cells {
            let r = row + p.row
            let c = col + p.col
            if r < 0 || r >= size || c < 0 || c >= size { return false }
            if grid[r][c] != nil { return false }
        }
        return true
    }

    /// Does `shape` fit ANYWHERE on the current board?
    func canPlaceAnywhere(_ shape: PieceShape) -> Bool {
        for row in 0...(size - shape.height) {
            for col in 0...(size - shape.width) {
                if canPlace(shape, atRow: row, col: col) { return true }
            }
        }
        return false
    }

    // MARK: Placing a piece

    /// Attempt to place the tray piece with `id` anchored at (row, col).
    /// Returns true if placement succeeded.
    @discardableResult
    func place(pieceID: UUID, atRow row: Int, col: Int, burstAt point: CGPoint? = nil) -> Bool {
        guard let idx = tray.firstIndex(where: { $0.id == pieceID && !$0.placed }) else { return false }
        let shape = tray[idx].shape
        guard canPlace(shape, atRow: row, col: col) else { return false }

        // Fill cells
        for p in shape.cells {
            grid[row + p.row][col + p.col] = shape.colorIndex
        }
        tray[idx].placed = true
        Haptics.placement()

        resolveClears(burstAt: point)
        return true
    }

    // MARK: Line clearing + scoring

    private func resolveClears(burstAt point: CGPoint?) {
        // Find full rows and columns
        var fullRows: [Int] = []
        var fullCols: [Int] = []

        for r in 0..<size where grid[r].allSatisfy({ $0 != nil }) { fullRows.append(r) }
        for c in 0..<size {
            var full = true
            for r in 0..<size where grid[r][c] == nil { full = false; break }
            if full { fullCols.append(c) }
        }

        let linesCleared = fullRows.count + fullCols.count

        if linesCleared == 0 {
            // No clear: the streak gets a grace window of `streakGrace`
            // placements. It only truly breaks after 3 in a row with no clear.
            missCount += 1
            if missCount >= streakGrace {
                streak = 0
                missCount = 0
            }
            lastLinesCleared = 0
            lastGain = 0
            finishTurnAndCheckGameOver()
            return
        }

        // Build set of cells to clear
        var cells = Set<GridPoint>()
        for r in fullRows { for c in 0..<size { cells.insert(GridPoint(row: r, col: c)) } }
        for c in fullCols { for r in 0..<size { cells.insert(GridPoint(row: r, col: c)) } }

        // --- Scoring ---
        missCount = 0          // a clear refills the grace window
        streak += 1
        let blocks = cells.count
        var gain = blocks * GameConfig.pointsPerBlock
        gain += comboBonus(forLines: linesCleared)
        let mult = streakMultiplier(streak)
        gain = Int((Double(gain) * mult).rounded())

        score += gain
        lastLinesCleared = linesCleared
        lastGain = gain
        comboPulse += 1

        if score > bestScore {
            bestScore = score
            UserDefaults.standard.set(bestScore, forKey: GameConfig.bestScoreKey)
        }

        // Haptics
        Haptics.lineClear()
        if linesCleared >= 2 { Haptics.combo() }

        // Big-combo flair
        if linesCleared >= 4 {
            screenFlash += 1
            if let pt = point {
                burstCenter = pt
                burstTrigger += 1
            }
        }

        // Animate the flash, then remove the cells
        clearingCells = cells
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.22) { [weak self] in
            guard let self else { return }
            for cell in cells { self.grid[cell.row][cell.col] = nil }
            self.clearingCells = []
            self.finishTurnAndCheckGameOver()
        }
    }

    private func comboBonus(forLines lines: Int) -> Int {
        switch lines {
        case 2: return 50
        case 3: return 100
        case 4: return 200
        case let n where n >= 5: return 400
        default: return 0
        }
    }

    private func streakMultiplier(_ s: Int) -> Double {
        switch s {
        case ...1: return 1.0
        case 2:    return 1.5
        case 3:    return 2.0
        case 4:    return 3.0
        case 5:    return 5.0
        // Higher streaks keep increasing the multiplier (+1x each), capped at 10x.
        default:   return min(10.0, 5.0 + Double(s - 5))
        }
    }

    // MARK: Turn end / spawning / game over

    private func finishTurnAndCheckGameOver() {
        // If all tray pieces placed, spawn a fresh set.
        if tray.allSatisfy({ $0.placed }) {
            refillTray()
        }
        checkGameOver()
    }

    private func checkGameOver() {
        // Game over if NONE of the remaining pieces fit anywhere.
        let remaining = activePieces
        guard !remaining.isEmpty else { return }
        let anyFits = remaining.contains { canPlaceAnywhere($0.shape) }
        if !anyFits {
            isGameOver = true
            Haptics.gameOver()
        }
    }

    // MARK: Reset

    func resetGame() {
        grid = Array(repeating: Array(repeating: nil, count: size), count: size)
        score = 0
        streak = 0
        missCount = 0
        isGameOver = false
        clearingCells = []
        lastLinesCleared = 0
        lastGain = 0
        refillTray()
    }
}
