//
//  ContentView.swift
//  BlockDrop
//
//  Root view: composes HUD, board, tray, and drives the drag-and-drop
//  placement with a live ghost preview.
//

import SwiftUI

struct ContentView: View {
    @StateObject private var vm = GameViewModel()

    // Drag state (all coordinates in the "root" coordinate space)
    @State private var boardFrame: CGRect = .zero
    @State private var draggingID: UUID? = nil
    @State private var dragShape: PieceShape? = nil
    @State private var dragLocation: CGPoint = .zero

    // How far above the finger the piece floats, so your finger doesn't
    // cover the landing spot. Kept small so the piece tracks the finger.
    private let lift: CGFloat = Layout.cell * 0.9

    var body: some View {
        ZStack {
            // Background
            LinearGradient(
                colors: [Color(red: 0.10, green: 0.10, blue: 0.18),
                         Color(red: 0.06, green: 0.06, blue: 0.12)],
                startPoint: .top, endPoint: .bottom)
                .ignoresSafeArea()

            // Main layout
            VStack(spacing: 16) {
                Text("BLOCKDROP")
                    .font(.system(size: 24, weight: .heavy, design: .rounded))
                    .foregroundColor(.white)
                    .tracking(4)
                    .padding(.top, 8)

                HUDView(vm: vm)

                BoardView(vm: vm, ghost: currentGhost)

                Spacer(minLength: 4)

                TrayView(
                    vm: vm,
                    draggingID: draggingID,
                    onDragChanged: handleDragChanged,
                    onDragEnded: handleDragEnded
                )
                .padding(.bottom, 8)
            }

            // Floating dragged piece
            if let shape = dragShape {
                PieceShapeView(shape: shape, cellSize: Layout.cell, opacity: 0.92)
                    .shadow(color: .black.opacity(0.4), radius: 8, y: 4)
                    .position(floatingCenter(for: shape))
                    .allowsHitTesting(false)
            }

            // Effects
            ScreenFlashView(trigger: vm.screenFlash)
            ParticleBurstView(trigger: vm.burstTrigger, center: vm.burstCenter)

            // Game over
            if vm.isGameOver {
                GameOverView(vm: vm)
                    .transition(.opacity)
            }
        }
        .coordinateSpace(name: Layout.coordSpace)
        .onPreferenceChange(BoardFramePreference.self) { boardFrame = $0 }
        .animation(.easeInOut, value: vm.isGameOver)
    }

    // MARK: - Drag handling

    private func handleDragChanged(id: UUID, shape: PieceShape, location: CGPoint) {
        draggingID = id
        dragShape = shape
        dragLocation = location
    }

    private func handleDragEnded(id: UUID, shape: PieceShape) {
        defer {
            draggingID = nil
            dragShape = nil
        }
        guard let ghost = currentGhost, ghost.valid else {
            return   // invalid -> snaps back to tray automatically
        }
        let center = dropBurstCenter(origin: ghost.origin, shape: shape)
        withAnimation(.easeOut(duration: 0.12)) {
            vm.place(pieceID: id, atRow: ghost.origin.row, col: ghost.origin.col, burstAt: center)
        }
    }

    // MARK: - Geometry helpers

    /// Top-left of the floating piece in root coordinates.
    /// The piece is centered on the finger horizontally and vertically,
    /// then lifted up a little so the finger doesn't hide the target.
    private func floatingTopLeft(for shape: PieceShape) -> CGPoint {
        let w = CGFloat(shape.width) * Layout.cell
        let h = CGFloat(shape.height) * Layout.cell
        return CGPoint(x: dragLocation.x - w / 2,
                       y: dragLocation.y - h / 2 - lift)
    }

    private func floatingCenter(for shape: PieceShape) -> CGPoint {
        let tl = floatingTopLeft(for: shape)
        let w = CGFloat(shape.width) * Layout.cell
        let h = CGFloat(shape.height) * Layout.cell
        return CGPoint(x: tl.x + w / 2, y: tl.y + h / 2)
    }

    /// The ghost preview for the current drag, if the piece is over the board.
    private var currentGhost: GhostInfo? {
        guard let shape = dragShape, boardFrame != .zero else { return nil }
        let tl = floatingTopLeft(for: shape)
        // Round to the nearest cell (works for negatives too).
        let col = Int(((tl.x - boardFrame.minX) / Layout.cell).rounded())
        let row = Int(((tl.y - boardFrame.minY) / Layout.cell).rounded())

        // Only show a ghost if the anchor is reasonably over the grid.
        guard row >= -1, row <= GameConfig.gridSize,
              col >= -1, col <= GameConfig.gridSize else { return nil }

        let valid = vm.canPlace(shape, atRow: row, col: col)
        return GhostInfo(origin: GridPoint(row: row, col: col), shape: shape, valid: valid)
    }

    /// Center point (root coords) of a placed piece, for the particle burst.
    private func dropBurstCenter(origin: GridPoint, shape: PieceShape) -> CGPoint {
        let x = boardFrame.minX + (CGFloat(origin.col) + CGFloat(shape.width) / 2) * Layout.cell
        let y = boardFrame.minY + (CGFloat(origin.row) + CGFloat(shape.height) / 2) * Layout.cell
        return CGPoint(x: x, y: y)
    }
}

#Preview {
    ContentView()
}
