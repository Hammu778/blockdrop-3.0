//
//  HUDView.swift
//  BlockDrop
//
//  The combo counter HUD: streak, current score, best score, with a
//  satisfying pop/flash whenever a combo lands.
//

import SwiftUI

struct HUDView: View {
    @ObservedObject var vm: GameViewModel

    @State private var pulseScale: CGFloat = 1.0
    @State private var flashOn: Bool = false

    private var streakActive: Bool { vm.streak >= 1 }

    var body: some View {
        VStack(spacing: 10) {

            // Score + Best
            HStack(spacing: 12) {
                statCard(title: "SCORE", value: "\(vm.score)",
                         tint: Color(red: 0.40, green: 0.55, blue: 0.99))
                statCard(title: "BEST", value: "\(vm.bestScore)",
                         tint: Color(red: 0.36, green: 0.84, blue: 0.50))
            }

            // Streak / combo banner
            ZStack {
                RoundedRectangle(cornerRadius: 16)
                    .fill(
                        LinearGradient(
                            colors: streakActive
                                ? [Color(red: 1.0, green: 0.55, blue: 0.10),
                                   Color(red: 1.0, green: 0.80, blue: 0.20)]
                                : [Color.white.opacity(0.06), Color.white.opacity(0.06)],
                            startPoint: .leading, endPoint: .trailing)
                    )
                    .overlay(
                        RoundedRectangle(cornerRadius: 16)
                            .stroke(Color.white.opacity(flashOn ? 0.9 : 0.12),
                                    lineWidth: flashOn ? 3 : 1)
                    )

                HStack(spacing: 10) {
                    Text(streakActive ? "🔥" : "✨")
                        .font(.system(size: 26))
                    if streakActive {
                        Text("x\(vm.streak)")
                            .font(.system(size: 30, weight: .heavy, design: .rounded))
                            .foregroundColor(.white)
                        Text("STREAK")
                            .font(.system(size: 18, weight: .heavy, design: .rounded))
                            .foregroundColor(.white.opacity(0.95))
                            .tracking(2)
                        Text(multiplierText(vm.currentMultiplier))
                            .font(.system(size: 18, weight: .heavy, design: .rounded))
                            .foregroundColor(Color(red: 0.10, green: 0.11, blue: 0.20))
                            .padding(.horizontal, 9)
                            .padding(.vertical, 3)
                            .background(Capsule().fill(Color.white.opacity(0.95)))
                    } else {
                        Text("BUILD A STREAK")
                            .font(.system(size: 16, weight: .bold, design: .rounded))
                            .foregroundColor(.white.opacity(0.5))
                            .tracking(2)
                    }
                    Spacer(minLength: 0)
                    if vm.lastLinesCleared >= 2 {
                        Text("+\(vm.lastGain)")
                            .font(.system(size: 20, weight: .heavy, design: .rounded))
                            .foregroundColor(.white)
                    }
                }
                .padding(.horizontal, 18)
            }
            .frame(height: 58)
            .scaleEffect(pulseScale)
        }
        .padding(.horizontal, 12)
        .onChange(of: vm.comboPulse) { _ in animatePulse() }
    }

    private func statCard(title: String, value: String, tint: Color) -> some View {
        VStack(spacing: 2) {
            Text(title)
                .font(.system(size: 12, weight: .bold, design: .rounded))
                .foregroundColor(.white.opacity(0.55))
                .tracking(2)
            Text(value)
                .font(.system(size: 26, weight: .heavy, design: .rounded))
                .foregroundColor(.white)
                .contentTransition(.numericText())
        }
        .frame(maxWidth: .infinity)
        .padding(.vertical, 8)
        .background(
            RoundedRectangle(cornerRadius: 14)
                .fill(Color.white.opacity(0.05))
                .overlay(RoundedRectangle(cornerRadius: 14).stroke(tint.opacity(0.5), lineWidth: 1))
        )
    }

    private func multiplierText(_ m: Double) -> String {
        m == m.rounded() ? "x\(Int(m))" : String(format: "x%.1f", m)
    }

    private func animatePulse() {
        // Scale up + flash, then settle.
        withAnimation(.spring(response: 0.18, dampingFraction: 0.4)) {
            pulseScale = 1.18
            flashOn = true
        }
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.22) {
            withAnimation(.spring(response: 0.35, dampingFraction: 0.6)) {
                pulseScale = 1.0
                flashOn = false
            }
        }
    }
}
