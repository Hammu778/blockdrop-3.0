# Getting the .ipa onto your iPhone — no Mac required

You build the .ipa in the cloud (GitHub's free macOS servers), download it, then
install it from your Windows PC. ~15 min the first time.

## Step 1 — Put the project on GitHub
1. Make a free account at github.com.
2. Click **New repository** → name it `BlockDrop` → **Create**.
3. On the repo page click **uploading an existing file**, then drag in EVERYTHING
   inside the `BlockDrop` folder (the `.github` folder, `BlockDrop.xcodeproj`,
   the `BlockDrop` source folder, etc.). Commit.
   - Important: the hidden `.github/workflows/build-ipa.yml` must be included —
     that's the build recipe. If drag-and-drop hides it, use GitHub Desktop, or
     create the file manually via "Add file → Create new file" and paste it in.

## Step 2 — Let GitHub build it
1. Go to the **Actions** tab of your repo.
2. The "Build IPA" workflow runs automatically on upload (or click it → **Run
   workflow**). Wait for the green check (~3–5 min).
3. Open the finished run → scroll to **Artifacts** → download
   **BlockDrop-unsigned-ipa**. Unzip it → you now have `BlockDrop-unsigned.ipa`. 🎉

## Step 3 — Install on your iPhone from Windows
This .ipa is unsigned, so use a free sideloading tool that re-signs it with your
own Apple ID (a normal free Apple account works):

**Sideloadly (easiest on Windows):**
1. Install Sideloadly from sideloadly.io (Windows version) + iTunes from Apple
   (needed for the device driver).
2. Plug in your iPhone, open Sideloadly.
3. Drag `BlockDrop-unsigned.ipa` into it, enter your Apple ID, click **Start**.
4. On your iPhone: **Settings → General → VPN & Device Management** → tap your
   Apple ID → **Trust**. Launch BlockDrop.

(AltStore is another option and supports auto-refreshing so it doesn't expire.)

## Heads up about free Apple accounts
A free (non-paid) Apple ID can sideload apps, but they **expire after 7 days** —
just re-run Sideloadly to refresh. A paid Apple Developer account ($99/yr) makes
it last a year. Either way, no Mac needed.

## TL;DR
GitHub builds the .ipa → you download it → Sideloadly puts it on your phone.
